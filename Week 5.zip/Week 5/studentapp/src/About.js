import React, { Component } from "react";

class About extends Component {
  render() {
    return (
      <div>
        <h3>Welcome to the About Page of the Student Management Portal</h3>
      </div>
    );
  }
}

export { About };